How to install:
1. Backup ~/.config/gtk4.0 directory
2. Replace gtk4.0 directory in ~/.config/gtk4.0
